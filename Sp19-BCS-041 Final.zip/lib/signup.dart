import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:email_validator/email_validator.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:table_app/screen1.dart';

import 'loginScreen.dart';



class signup extends StatefulWidget {
  const signup({Key? key}) : super(key: key);

  @override
  State<signup> createState() => _signupState();
}

class _signupState extends State<signup> {
  @override
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _email = TextEditingController();
  final TextEditingController _password = TextEditingController();
  FirebaseAuth auth = FirebaseAuth.instance;

  Widget build(BuildContext context) {
    return Scaffold(

      backgroundColor: Colors.brown,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [

              SizedBox(height: 200,),

              Container(
                decoration: BoxDecoration(
                    color: Colors.brown,

                    borderRadius: BorderRadius.all(Radius.circular(20))
                ),

                child: Form(

                  key: _formKey,
                  child: Center(
                    child: Container(
                      width: 350,
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [

                          Text("Sign Up",style: TextStyle(

                            color: Colors.blue,
                            fontSize: 50.0,
                            fontWeight: FontWeight.bold,
                            fontFamily: "sans-serif-condensed"

                          ),),
                          SizedBox(
                            height: 30,
                          ),
                          TextFormField(
                            controller: _email,
                            decoration: InputDecoration(

                              hintText: "Email",
                              hintStyle: TextStyle(
                                  color: Colors.black, fontSize: 16),
                              filled: true,
                              fillColor: Colors.white,
                              contentPadding: EdgeInsets.all(10),

                            ),
                            style: TextStyle(
                              color: Colors.black,
                            ),
                            keyboardType: TextInputType.emailAddress,
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Please enter an email';
                              }
                              if (!EmailValidator.validate(value)) {
                                return 'Enter a valid email address';
                              }
                              return null;
                            },
                          ),
                          SizedBox(
                            height: 30,
                          ),
                          TextFormField(
                            controller: _password,
                            obscureText: true,

                            decoration: InputDecoration(

                              hintText: "Password",
                              hintStyle: TextStyle(
                                  color: Colors.black, fontSize: 16),
                              filled: true,
                              fillColor: Colors.white,
                              contentPadding: EdgeInsets.all(10),

                            ),
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Please enter a password';
                              }
                              if (value.length < 8) {
                                return 'Password must be at least 8 characters';
                              }

                              return null;
                            },
                          ),
                          SizedBox(
                            height: 30,
                          ),
                          ElevatedButton(
                            style: ButtonStyle(
                                backgroundColor: MaterialStateProperty.all(Colors.blue),


                            ),
                            child: Text('Sign Up', style: TextStyle(fontSize: 24)),
                            // Black foreground color
                            onPressed: () async {

                              if (_formKey.currentState!.validate()) {
                                // if (_email.text.isEmpty) {
                                //   var _ModelUser = ModelUser();
                                //   _ModelUser.email = _email.text.trim();
                                //   _ModelUser.pass = _password.text;
                                //   _ModelUser.username = _username.text;
                                //
                                //   var result =
                                //       await _userService.SaveUserAccount(_ModelUser);
                                //   if (result != null) {
                                //     _email.clear();
                                //     _username.clear();
                                //     _password.clear();
                                //
                                //     const snackBar = SnackBar(
                                //       content: Text('Account Create Successfully'),
                                //     );
                                //     ScaffoldMessenger.of(context)
                                //         .showSnackBar(snackBar);
                                //     Navigator.pushReplacement(
                                //         context,
                                //         MaterialPageRoute(
                                //             builder: (context) => screen1()));
                                //   } else {
                                //     const snackBar = SnackBar(
                                //       content: Text('Somthing went wrong'),
                                //     );
                                //     ScaffoldMessenger.of(context)
                                //         .showSnackBar(snackBar);
                                //   }
                                // } else {
                                //   showDialog(
                                //       context: context,
                                //       builder: (BuildContext context) {
                                //         return AlertDialog(
                                //           title: Center(
                                //               child: Text(
                                //             'Error',
                                //             style: TextStyle(color: Colors.red),
                                //           )),
                                //           content: Text(
                                //               "Account already created. Please reinstall the app then create account."),
                                //           shape: RoundedRectangleBorder(
                                //               borderRadius:
                                //                   BorderRadius.circular(20)),
                                //           elevation: 12,
                                //           actions: [
                                //             Center(
                                //               child: TextButton(
                                //                 onPressed: () {
                                //                   Navigator.of(context).pop();
                                //                 },
                                //                 child: Text(
                                //                   'OK',
                                //                   style:
                                //                       TextStyle(color: Colors.white),
                                //                 ),
                                //               ),
                                //             ),
                                //           ],
                                //         );
                                //       });
                                // }
                                try {
                                  UserCredential userCredential = await FirebaseAuth
                                      .instance
                                      .createUserWithEmailAndPassword(
                                    email: _email.text,
                                    password: _password.text,
                                  );
                                  FirebaseFirestore.instance
                                      .collection('guess')
                                      .doc(userCredential.user?.uid)
                                      .collection('profile')
                                      .doc()
                                      .set({
                                    "username": "saad",
                                    'email': _email.text.trim(),
                                  });
                                  if (userCredential != null) {
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => screen1()),
                                    );
                                  }
                                  //Get.to(HomeScreen());
                                } on FirebaseAuthException catch (e) {
                                  if (e.code == 'weak-password') {
                                    final snackBar = SnackBar(
                                      backgroundColor: Colors.red,
                                      content: Text(
                                        e.toString(),
                                        style: TextStyle(color: Colors.white),
                                      ),
                                    );
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(snackBar);
                                  } else if (e.code == 'email-already-in-use') {
                                    final snackBar = SnackBar(
                                      backgroundColor: Colors.red,
                                      content: Text(
                                        e.toString(),
                                        style: TextStyle(color: Colors.white),
                                      ),
                                    );
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(snackBar);
                                  }
                                }
                              }
                              // Code to execute when the button is pressed
                            },
                          ),
                          Row(
                            children: [
                              SizedBox(
                                width: 70,
                              ),
                              Text('Already have an account? ',style: TextStyle(color: Colors.red),),
                              TextButton(
                                child: Text('Login'),
                                onPressed: () {
                                  Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => login()));
                                  // Code to execute when the button is pressed
                                },
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
