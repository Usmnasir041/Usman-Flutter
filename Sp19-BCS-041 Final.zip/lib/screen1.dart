import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:sqflite/sqflite.dart';

import 'loginScreen.dart';
import 'screen2.dart';
import 'tablepage.dart';



class screen1 extends StatefulWidget {
  @override
  _screen1State createState() => _screen1State();
}

class _screen1State extends State<screen1> {
  static late Database _db;
  static const columnUid = '';
  int sliderheight=1;
  int sliderheight1=10;
  int sliderheight2=10;

  bool  a=false;
  int  num=1;

  @override
  Widget build(BuildContext context) {


      List<Widget> table = [];
      for (int i = 1; i <= 10; i++) {
        table.add(Visibility(
          visible: a,
          child: Text(
            '$num x $i = ${num * i} ',
            style: TextStyle(fontSize: 20,
            color: Colors.white),
          ),
        ));

      }

      void logout(){
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              backgroundColor: Colors.brown.shade500,
              title: Text("Logout"),
              content: Text("Are you sure you want to logout?"),
              actions: [

                TextButton(
                  style: ElevatedButton.styleFrom(
                    primary: Colors.blue, // Background color
                    onPrimary: Colors.white,
                    // Text Color (Foreground color)
                  ),
                  child: Text("Logout"),
                  onPressed:(){
                    FirebaseAuth.instance.signOut();
// _db.close();
                    // Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>login()));

                    Get.offAll(login());
                    Navigator.pop(context);


                  },

                ),
                TextButton(
                  style: ElevatedButton.styleFrom(
                    primary: Colors.blue, // Background color
                    onPrimary: Colors.white,
                    // Text Color (Foreground color)
                  ),
                  child: Text("Cancel"),
                  onPressed: () {

                    Navigator.pop(context);

                  },
                ),
              ],
            );
          },
        );

      }









    return Scaffold(

      appBar: AppBar(
        title:  Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 80),
              child: Text('Table App',style:TextStyle(color:Colors.white,fontSize: 20,)),
            ),
            Spacer(),
            TextButton(onPressed: (){
              logout();
            }, child: Icon(
              Icons.logout,
              color: Colors.white,
            ))
          ],
        ),
        backgroundColor: Colors.brown,
      ),
      body:

      Container(
        color: Colors.white,


        child: ListView(
          children: [Column(



            children: <Widget>[
              Row(

                crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Text("Select Table",
                      style: TextStyle(
                        color: Colors.blue,
                        fontSize: 30,

                      ),),
                    ),
                ],
                ),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(sliderheight.toString(),
                  style: TextStyle(
                    color: Colors.blue,
                    fontSize: 20,
                    fontWeight: FontWeight.bold
                  ),),

                ],),

              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Slider(value: sliderheight.toDouble()
                      ,min: 1,
                      max: 50,
                      activeColor: Colors.blue,
                      inactiveColor:Color(0xFF8D8E98),
                      onChanged: (double newvalue){
                        setState(() {
                          sliderheight=newvalue.round();
                        });
                      }),
                ],
              ),











SizedBox(height: 200,),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  SizedBox(
                    height: 40,
                    width: 75,
                    child:   TextButton(onPressed: (){

                      if(sliderheight1 > sliderheight2){
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              backgroundColor: Colors.tealAccent.shade100,
                              title: Text("ERROR!",style: TextStyle(color: Colors.red),),
                              content: Text("START number should be < the END number "),
                              actions: <Widget>[
                                Container(

                                  decoration: BoxDecoration(
                                    color: Colors.blue,
                                    borderRadius: BorderRadius.circular(50.0),
                                  ),
                                  child: TextButton(

                                    child: Text("OK",style: TextStyle(color: Colors.white)),
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },

                                  ),
                                ),
                              ],
                            );
                          },
                        );


                      }
else {
                        Navigator.push(
                            context, MaterialPageRoute(builder: (context) =>
                            tableshow(tab: sliderheight,
                              start: 1,
                              end: 10,)));
                      }
                    },

                        child: Text("Generate",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,

                          ),),
                        style:  TextButton.styleFrom(backgroundColor: Colors.brown)

                    ),
                  ),


                ],
              ),


            ],
          )],
        ),
      ),
    );
  }
}
