import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'db.dart';


class offline extends StatefulWidget {
  offline({required this.id , });
  final String id;


  @override
  State<offline> createState() => _offlineState();
}

class _offlineState extends State<offline> {
  final dbHelper = DatabaseHelper();

  @override
  Widget build(BuildContext context) {
    var id=widget.id;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title:
        Padding(
          padding: const EdgeInsets.only(left: 70),
          child: Text('Offline Record'),
        ),
        backgroundColor: Colors.brown,
      ),

      body: Center(
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: dbHelper.mydb().then((db) => dbHelper.queryAllRows(id)),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              List<Map<String, dynamic>>? rows = snapshot.data;
              return ListView.builder(
                itemCount: rows?.length,
                itemBuilder: (context, index) {
                  Map<String, dynamic> list = rows![index];
                  return Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Container(
                      height:100,
                      width: MediaQuery
                          .of(context)
                          .size
                          .width,
                      decoration: BoxDecoration(
                          color: Colors.brown.shade100,
                          borderRadius: BorderRadius.circular(20)),
                      child: Row(
                        children: [
                          Flexible(
                            flex: 5,
                            child: Column(
                              children: [
                                Row(

                                  children: [
                                    SizedBox(
                                      width: 20,
                                    ),

                                    Spacer(),
                                    SizedBox(
                                      width: 20,
                                    ),
                                  ],

                                ),

                                Padding(
                                  padding: const EdgeInsets.only(
                                      top: 15, left: 15, right: 15),
                                  child: Row(
                                    children: [
                                      Text(
                                        "Right Answers",
                                        style: TextStyle(color: Colors.black),
                                      ),
                                      Spacer(),
                                      Text(
                                        list['correct'],
                                        style: TextStyle(color: Colors.black),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      top: 15, left: 15, right: 15),
                                  child: Row(
                                    children: [
                                      Text(
                                        "Wrong Answers",
                                        style: TextStyle(color: Colors.black),
                                      ),
                                      Spacer(),
                                      Text(
                                        list['wrong'],
                                        style: TextStyle(color: Colors.black),
                                      ),
                                    ],
                                  ),
                                ),

                              ],
                            ),
                          ),

                        ],
                      ),
                    ),
                  );
                  // return ListTile(
                  //   title: Text(list['phone']),
                  //   subtitle: Text(list['reg'].toString()),
                  // );
                },
              );
            } else {
              return CircularProgressIndicator();
            }
          },
        ),
      ),
    );
  }
}
