import 'package:flutter/material.dart';
import 'screen1.dart';
import 'dart:math';
import 'result.dart';
import 'package:shared_preferences/shared_preferences.dart';

class screen2 extends StatefulWidget {
  screen2({required this.number , required this.question});
  final int number;
  final int question;

  @override
  _screen2State createState() => _screen2State();
}

class _screen2State extends State<screen2> {


  Random r1 = new Random();
  int  a =0;
  int b=0 ;
  int c=0;
  int d=0 ;
  int e=0;
  int priority =0;
int number=0;


  bool clr1=true;
  bool clr2=true;
  bool clr3=true;
  bool clr4=true;
  bool ans1=false;
  bool ans2=false;
  bool ans3=false;
  bool ans4=false;
 bool v=true;
 bool btnvisible=true;
 int count=1;
  int right=0;
  int wrong=0;
  bool result1 =true;

  void rightf(){
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.brown.shade500,

          content: Text("Right Answer",style: TextStyle(color: Colors.greenAccent),),
          actions: [

            Center(
              child: TextButton(onPressed: (){





                  if(count==widget.question){
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>result(r:right, w:wrong , t: widget.question,)));

                  }
                  else{
                    setState(() {
                      right++;
                      count++;
                      a = r1.nextInt(10) + 1;
                      priority=r1.nextInt(3) + 1;
                      Navigator.pop(context);
                    });


                  }







                // Navigator.pop(context);
              }, child:  Text("Next Question",style: TextStyle(color: Colors.white)),
                  style:  TextButton.styleFrom(backgroundColor: Colors.blue)),
            ),

          ],
        );
      },
    );

  }
  void wrongf(){
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.brown.shade500,

          content: Text("Wrong Answer",style: TextStyle(color: Colors.red)),
          actions: [

            Center(
              child: TextButton(onPressed: (){





                  if(count==widget.question){

                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>result(r:right, w:wrong , t: widget.question,)));

                  }
                  else{
                    setState(() {

                      count++;
                      wrong++;
                      a = r1.nextInt(10) + 1;
                      priority=r1.nextInt(3) + 1;
                      Navigator.pop(context);
                    });


                  }






                // Navigator.pop(context);
              }, child:  Text("Next Question",style: TextStyle(color: Colors.white)),
                  style:  TextButton.styleFrom(backgroundColor: Colors.blue)),
            ),
          ],
        );
      },
    );

  }
  @override
  Widget build(BuildContext context) {


    return Scaffold(
      appBar: AppBar(
        title:  Center(
          child: const Text('Table App',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20.0,
              fontWeight: FontWeight.bold,

            ),),
        ), backgroundColor: Colors.brown,
      ),
      body: Container(
        color: Colors.white,
        child: Column(
          children: <Widget>[
            Row(
        mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[Padding(
                padding: const EdgeInsets.all(20.0),
                child: SizedBox(

                  child: Visibility(
                    visible: true,
                    child: TextButton(onPressed: (){
                     setState(() {

                         number=widget.number;
                         a =r1.nextInt(10) + 1;
                         b = r1.nextInt(4) + 1;
                         c = r1.nextInt(8) + 5;
                         d = r1.nextInt(12) + 9;
                         e = r1.nextInt(16) + 13;
                         priority=r1.nextInt(3) + 1;
                         count=0;
                         wrong=0;
                         right=0;


                      });
      }, child: Text("Start",
                    style: TextStyle(color: Colors.red,
                    fontSize: 15,
                    fontWeight: FontWeight.bold),),
                    style:  TextButton.styleFrom(backgroundColor: Colors.white)),
                  ),
                ),
              )
                ],
            ),


            Visibility(
              visible: btnvisible,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(0, 10,0 ,20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[Text("$number x $a = _____",
                    style: TextStyle(
                      color: Colors.blue,
                      fontWeight: FontWeight.bold,
                      fontSize: 30,
                    ),),
                  ],
                ),
              ),
            ),



            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SizedBox(
                    height: 50,
                    width: 60,
                    child: Visibility(
                      visible: btnvisible,
                      child: TextButton(
                          child: (priority==1) ? Text("${number*a}",style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold),):Text("${(number*a)+b}",style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold)),
                          onPressed: (){


                              if(priority==1){


rightf();

                              }
                              else{

                             wrongf();
                              }







                      },
                          style:  TextButton.styleFrom(
                              backgroundColor:Colors.brown
                          )

                      ),
                    ),
                  ),
                ),


                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SizedBox(
                    height: 50,
                    width: 60,
                    child: Visibility(
                      visible: btnvisible,
                      child: TextButton(
                          child: (priority==2) ? Text("${number*a}",style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold)):Text("${(number*a)+c}",style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold)),
                          onPressed: (){


                              if(priority==2){


                                rightf();
                              }
                              else{

                               wrongf();
                              }



                      },
                          style:  TextButton.styleFrom(
                              backgroundColor: Colors.brown)
                      ),
                    ),
                  ),
                ),
              ],
            ),


            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SizedBox(
                    height: 50,
                    width: 60,
                    child: Visibility(
                      visible: btnvisible,
                      child: TextButton(
                          child: (priority==3) ? Text("${number*a}",style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold)):Text("${(number*a)+d}",style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold)),
                          onPressed: (){


                              if(priority==3){


                                rightf();

                              }
                              else{

                             wrongf();
                              }


                      },
                          style:  TextButton.styleFrom(
                              backgroundColor: Colors.brown)
                      ),
                    ),
                  ),
                ),

              ],
            ),


            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[









              ],
            ),
          ],
        ),
      ),
    );
  }
}
