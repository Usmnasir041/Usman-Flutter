import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:table_app/tablepage.dart';

import 'package:table_app/online.dart';
import 'db.dart';
import 'main.dart';
import 'screen1.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'offline.dart';
import 'main.dart';
final dbHelper = DatabaseHelper();

class result extends StatefulWidget {

 result({required this.r ,required this.w, required this.t});
  final int r;
 final int w;
 final int t;

  @override
  State<result> createState() => _resultState();
}

class _resultState extends State<result> {

  var uid ;
 // late int r;
 // late int w;
 // void initState()  {
 //   // TODO: implement initState
 //   super.initState();
 //
 //   isLogin();
 // }
 //  void isLogin()async{
 //    SharedPreferences sp = await SharedPreferences.getInstance() ;
 //    sp.setInt('right', widget.r);
 //    sp.setInt('wrong', widget.w);
 //
 //    r = sp.getInt('right') ?? 0;
 //    w = sp.getInt('wrong') ?? 0;
 //
 //
 //
 //  }

  void showdia() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Message"),
          content: Row(
            children: [
              Text("Save Successfully"),
            ],
          ),
          actions: [
            TextButton(
              style: ElevatedButton.styleFrom(
                primary: Colors.deepPurple, // Background color
                onPrimary: Colors.white,
                // Text Color (Foreground color)
              ),
              child: Text("OK"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
  var user = FirebaseAuth.instance.currentUser;
  @override
  Widget build(BuildContext context) {
    var r=widget.r;
    var w=widget.w;
    var t=widget.t;

    return Scaffold(
      appBar: AppBar(
        title:  Center(
          child: const Text('Table App',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20.0,
              fontWeight: FontWeight.bold,

            ),),
        ), backgroundColor: Colors.brown,
      ),

      body: Container(
        color: Colors.white,
        child: Column(
          children: <Widget>[

            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text("RESULT",style: TextStyle(
                    color: Colors.black,
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),)
                ],
              ),


            ),





            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 30, 0, 0),
                  child: Text("Right : ",style: TextStyle(
                    color: Colors.blue,
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(0, 30, 0, 0),
                  child: Text("${widget.r}",style: TextStyle(
                    color: Colors.blue,
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),),
                ),


              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
                  child: Text("Wrong : ",style: TextStyle(
                    color: Colors.blue,
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                  child: Text("${widget.w}",style: TextStyle(
                    color: Colors.blue,
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),),
                ),

              ],
            ),

SizedBox(height: 50,),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                TextButton(
                    onPressed:() async{
                      setState(() {
                        uid= FirebaseAuth.instance.currentUser?.uid;
                      });
                      Map<String, dynamic> row = {
                        DatabaseHelper.columnUid: uid,
                        DatabaseHelper.columnWrong: w,
                        DatabaseHelper.columnCorrect: r,
                        DatabaseHelper.columnTotal: t,
                      };
                      final id = await dbHelper.insert(row);
                      debugPrint('inserted row id: $id');
                      const snackBar = SnackBar(
                        content: Text('Data Saved '),
                        backgroundColor: Colors.brown,
                      );
                      ScaffoldMessenger.of(context)
                          .showSnackBar(snackBar);
                    },

                    child:  Text("Save Offline",style: TextStyle(color: Colors.white),),
                    style:  TextButton.styleFrom(backgroundColor: Colors.brown)),
                SizedBox(width: 20,),

                TextButton(onPressed: (){
                  setState(() {
                    uid= FirebaseAuth.instance.currentUser?.uid;
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>offline(id: uid,)));
                  });


                }, child:  Text("View ",style: TextStyle(color: Colors.white),),
                    style:  TextButton.styleFrom(backgroundColor: Colors.brown)),
              ],
            ),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                TextButton(onPressed: (){
                  var result = FirebaseFirestore.instance
                      .collection("myuser")
                      .doc(user?.uid)
                      .collection('result')
                      .add({
                    "Total":t ,
                    "Right":r ,
                    "Wrong":w ,
                  });
                  if (result != null) {
                    const snackBar = SnackBar(
                      content: Text('Data Saved'),
                      backgroundColor: Colors.brown,
                    );
                    ScaffoldMessenger.of(context)
                        .showSnackBar(snackBar);

                  }
                }, child:  Text("\tSave Online",style: TextStyle(color: Colors.white),),
                    style:  TextButton.styleFrom(backgroundColor: Colors.brown)),
                SizedBox(width: 20,),

                TextButton(onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>online()));
                }, child:  Text("View ",style: TextStyle(color: Colors.white),),
                    style:  TextButton.styleFrom(backgroundColor: Colors.brown)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
