import 'package:flutter/material.dart';

import 'package:table_app/screen2.dart';
import 'screen1.dart';


class tableshow extends StatefulWidget {
  tableshow({required this.tab , required this.start , required this.end});


  final int tab;
  final int start;
  final int end;


  @override
  State<tableshow> createState() => _tableshowState();
}

class _tableshowState extends State<tableshow> {
  @override
  Widget build(BuildContext context) {
    int start=widget.start;
        int end=widget.end;
    int tab=widget.tab;


    List<Widget> table = [];
    for (int i = start; i <= end; i++) {
      table.add(Text(
        '$tab x $i = ${tab * i} ',
        style: TextStyle(fontSize: 20,
            color: Colors.blue),
      ));

    }



    return Scaffold(

      appBar: AppBar(
        title:  Center(
          child: const Text('Table App',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20.0,
              fontWeight: FontWeight.bold,

            ),),
        ), backgroundColor: Colors.brown,
      ),
      body:

      Container(
        color: Colors.white,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[

            SizedBox(height: 50,),

            Padding(
              padding: const EdgeInsets.fromLTRB(0, 30, 0, 0),
              child: Column(
                children: [
                  SizedBox(

                    child: Container(

                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(

                          children: table,
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),

SizedBox(height: 50,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[


                SizedBox(
                  height: 40,
                  width: 100,
                  child: TextButton(onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>screen2(number:widget.tab,question: 5,)));

                  }, child:Text("Quiz",
                    style: TextStyle(
                        color: Colors.white,

                        fontWeight: FontWeight.bold
                    ),
                  ),style:  TextButton.styleFrom(backgroundColor: Colors.brown)
                  ),
                )

              ],
            ),

          ],
        ),
      ),
    );
  }
}
