import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'db.dart';

final dbHelper = DatabaseHelper();
class online extends StatefulWidget {
  const online({Key? key}) : super(key: key);

  @override
  State<online> createState() => _onlineState();
}

class _onlineState extends State<online> {

  User? current = FirebaseAuth.instance.currentUser;
  List<dynamic> Total = [];
  List<dynamic> Right = [];
  List<dynamic> Wrong = [];
  getdata() async {
    await FirebaseFirestore.instance
        .collection("myuser")
        .doc(current?.uid)
        .collection('result')
        .get()
        .then((value) {
      for (int i = 0; i < value.docs.length; i++)
        setState(() {
          Total.add(value.docs[i].get('Total'));
          Right.add(value.docs[i].get('Right'));
          Wrong.add(value.docs[i].get('Wrong'));
        });
    });
  }

  void initState() {
    super.initState();
    getdata();

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title:
        Padding(
          padding: const EdgeInsets.only(left: 60),
          child: Text('Online Record'),
        ),
        backgroundColor: Colors.brown,
      ),

      body: Center(
        child: ListView.builder(
          itemCount: Total?.length,
          itemBuilder: (context, index) {

            return Padding(
              padding: const EdgeInsets.all(10.0),
              child: Container(
                height:100,
                width: MediaQuery
                    .of(context)
                    .size
                    .width,
                decoration: BoxDecoration(
                    color: Colors.brown.shade100,
                    borderRadius: BorderRadius.circular(20)),
                child: Row(
                  children: [
                    Flexible(
                      flex: 5,
                      child: Column(
                        children: [
                          Row(

                            children: [
                              SizedBox(
                                width: 20,
                              ),

                              Spacer(),
                              SizedBox(
                                width: 20,
                              ),
                            ],

                          ),

                          Padding(
                            padding: const EdgeInsets.only(
                                top: 15, left: 15, right: 15),
                            child: Row(
                              children: [
                                Text(
                                  "Right Answer",
                                  style: TextStyle(color: Colors.black),
                                ),
                                Spacer(),
                                Text(
                                  Right[index].toString(),
                                  style: TextStyle(color: Colors.black),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                top: 15, left: 15, right: 15),
                            child: Row(
                              children: [
                                Text(
                                  "Wrong Answer",
                                  style: TextStyle(color:Colors.black),
                                ),
                                Spacer(),
                                Text(
                                  Wrong[index].toString(),
                                  style: TextStyle(color: Colors.black),
                                ),
                              ],
                            ),
                          ),

                        ],
                      ),
                    ),

                  ],
                ),
              ),
            );
            // return ListTile(
            //   title: Text(list['phone']),
            //   subtitle: Text(list['reg'].toString()),
            // );
          },
        ),
      ),
    );
  }
}
