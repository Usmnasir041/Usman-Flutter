package com.example.prayer_beads

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
